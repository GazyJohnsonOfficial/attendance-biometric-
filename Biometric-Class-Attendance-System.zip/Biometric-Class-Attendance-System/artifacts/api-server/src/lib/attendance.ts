import { and, asc, desc, eq, inArray, or } from "drizzle-orm";
import {
  attendanceAuditTable,
  attendanceClassesTable,
  attendanceRecordsTable,
  attendanceRosterTable,
  attendanceSessionsTable,
  db,
  type AttendanceClass,
  type AttendanceSession,
} from "@workspace/db";

export async function findOwnedClass(
  classId: string,
  ownerUserId: string,
): Promise<AttendanceClass | null> {
  const [classroom] = await db
    .select()
    .from(attendanceClassesTable)
    .where(
      and(
        eq(attendanceClassesTable.id, classId),
        eq(attendanceClassesTable.ownerUserId, ownerUserId),
        eq(attendanceClassesTable.archived, false),
      ),
    )
    .limit(1);

  return classroom ?? null;
}

export async function findOwnedSession(
  sessionId: string,
  ownerUserId: string,
): Promise<AttendanceSession | null> {
  const [result] = await db
    .select({ session: attendanceSessionsTable })
    .from(attendanceSessionsTable)
    .innerJoin(
      attendanceClassesTable,
      eq(attendanceSessionsTable.classId, attendanceClassesTable.id),
    )
    .where(
      and(
        eq(attendanceSessionsTable.id, sessionId),
        eq(attendanceClassesTable.ownerUserId, ownerUserId),
      ),
    )
    .limit(1);

  return result?.session ?? null;
}

export async function getClassItem(classroom: AttendanceClass) {
  const [rosterRows, sessions] = await Promise.all([
    db
      .select({
        linkStatus: attendanceRosterTable.linkStatus,
        faceEnrolled: attendanceRosterTable.faceEnrolled,
      })
      .from(attendanceRosterTable)
      .where(eq(attendanceRosterTable.classId, classroom.id)),
    db
      .select()
      .from(attendanceSessionsTable)
      .where(eq(attendanceSessionsTable.classId, classroom.id))
      .orderBy(desc(attendanceSessionsTable.startsAt)),
  ]);

  const finalizedSessions = sessions.filter(
    (session) => session.status === "finalized",
  );
  const finalizedIds = finalizedSessions.map((session) => session.id);
  const finalizedRecords =
    finalizedIds.length > 0
      ? await db
          .select({ status: attendanceRecordsTable.status })
          .from(attendanceRecordsTable)
          .where(
            and(
              inArray(attendanceRecordsTable.sessionId, finalizedIds),
              or(
                eq(attendanceRecordsTable.status, "present"),
                eq(attendanceRecordsTable.status, "excused"),
              ),
            ),
          )
      : [];
  const denominator = finalizedSessions.reduce(
    (total, session) => total + rosterRows.length,
    0,
  );

  return {
    id: classroom.id,
    department: classroom.department,
    programme: classroom.programme,
    level: classroom.level,
    courseCode: classroom.courseCode,
    courseTitle: classroom.courseTitle,
    semester: classroom.semester,
    academicYear: classroom.academicYear,
    rosterCount: rosterRows.length,
    registeredCount: rosterRows.filter(
      (row) => row.linkStatus === "matched" || row.linkStatus === "needs_approval",
    ).length,
    faceEnrolledCount: rosterRows.filter((row) => row.faceEnrolled).length,
    averageAttendance:
      denominator > 0
        ? Math.round((finalizedRecords.length / denominator) * 1000) / 10
        : 0,
    lastSessionAt: sessions[0]?.startsAt ?? null,
    createdAt: classroom.createdAt,
  };
}

export async function getRosterResponse(classId: string) {
  const rows = await db
    .select()
    .from(attendanceRosterTable)
    .where(eq(attendanceRosterTable.classId, classId))
    .orderBy(asc(attendanceRosterTable.fullName));

  return {
    rows: rows.map((row) => ({
      id: row.id,
      fullName: row.fullName,
      indexNumber: row.indexNumber,
      email: row.email,
      phone: row.phone,
      linkStatus: row.linkStatus,
      faceEnrolled: row.faceEnrolled,
    })),
    rosterCount: rows.length,
    registeredCount: rows.filter(
      (row) => row.linkStatus === "matched" || row.linkStatus === "needs_approval",
    ).length,
    faceEnrolledCount: rows.filter((row) => row.faceEnrolled).length,
  };
}

export async function getSessionItem(session: AttendanceSession) {
  const [rosterRows, recordRows] = await Promise.all([
    db
      .select({ id: attendanceRosterTable.id })
      .from(attendanceRosterTable)
      .where(eq(attendanceRosterTable.classId, session.classId)),
    db
      .select({ status: attendanceRecordsTable.status })
      .from(attendanceRecordsTable)
      .where(eq(attendanceRecordsTable.sessionId, session.id)),
  ]);

  return {
    id: session.id,
    classId: session.classId,
    topic: session.topic,
    startsAt: session.startsAt,
    endsAt: session.endsAt,
    venue: session.venue,
    expectedStudents: session.expectedStudents,
    codeMode: session.codeMode,
    radiusM: session.radiusM,
    status: session.status,
    rosterCount: rosterRows.length,
    checkedInCount: recordRows.filter(
      (record) =>
        record.status === "present" ||
        record.status === "needs_review" ||
        record.status === "excused",
    ).length,
    reviewCount: recordRows.filter((record) => record.status === "needs_review")
      .length,
    createdAt: session.createdAt,
  };
}

export async function getSessionRecords(sessionId: string) {
  const rows = await db
    .select({
      record: attendanceRecordsTable,
      studentName: attendanceRosterTable.fullName,
      indexNumber: attendanceRosterTable.indexNumber,
    })
    .from(attendanceRecordsTable)
    .innerJoin(
      attendanceRosterTable,
      eq(attendanceRecordsTable.rosterStudentId, attendanceRosterTable.id),
    )
    .where(eq(attendanceRecordsTable.sessionId, sessionId))
    .orderBy(asc(attendanceRosterTable.fullName));

  return rows.map(({ record, studentName, indexNumber }) => ({
    id: record.id,
    sessionId: record.sessionId,
    studentName,
    indexNumber,
    status: record.status,
    markedAt: record.markedAt,
    flags: record.flags,
    note: record.note,
    markedManually: record.markedManually,
  }));
}

export async function getSessionDetail(session: AttendanceSession) {
  const [sessionItem, records] = await Promise.all([
    getSessionItem(session),
    getSessionRecords(session.id),
  ]);

  return { session: sessionItem, records };
}

export async function writeAttendanceAudit(
  actorUserId: string,
  entityType: string,
  entityId: string,
  action: string,
  details: Record<string, unknown> = {},
): Promise<void> {
  await db.insert(attendanceAuditTable).values({
    actorUserId,
    entityType,
    entityId,
    action,
    details,
  });
}

export async function getClassSessions(classId: string) {
  const sessions = await db
    .select()
    .from(attendanceSessionsTable)
    .where(eq(attendanceSessionsTable.classId, classId))
    .orderBy(desc(attendanceSessionsTable.startsAt));

  return Promise.all(sessions.map((session) => getSessionItem(session)));
}

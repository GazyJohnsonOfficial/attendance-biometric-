import { Router, type IRouter } from "express";
import classesRouter from "./classes";
import overviewRouter from "./overview";
import sessionsRouter from "./sessions";

const router: IRouter = Router();

router.use(classesRouter);
router.use(sessionsRouter);
router.use(overviewRouter);

export default router;

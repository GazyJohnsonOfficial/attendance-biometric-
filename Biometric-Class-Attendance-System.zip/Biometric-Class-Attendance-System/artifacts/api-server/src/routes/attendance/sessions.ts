import { createHmac } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CloseSessionParams,
  CloseSessionResponse,
  CreateManualMarkBody,
  CreateManualMarkParams,
  CreateManualMarkResponse,
  CreateSessionBody,
  CreateSessionParams,
  CreateSessionResponse,
  DecideAttendanceRecordBody,
  DecideAttendanceRecordParams,
  DecideAttendanceRecordResponse,
  FinalizeSessionParams,
  FinalizeSessionResponse,
  GetReviewQueueParams,
  GetReviewQueueResponse,
  GetSessionCodeParams,
  GetSessionCodeResponse,
  GetSessionParams,
  GetSessionResponse,
  ListClassSessionsParams,
  ListClassSessionsResponse,
} from "@workspace/api-zod";
import {
  attendanceAuditTable,
  attendanceClassesTable,
  attendanceRecordsTable,
  attendanceRosterTable,
  attendanceSessionsTable,
  db,
} from "@workspace/db";
import requireLecturer from "../../middlewares/requireLecturer";
import {
  findOwnedClass,
  findOwnedSession,
  getClassSessions,
  getSessionDetail,
  getSessionItem,
  getSessionRecords,
  writeAttendanceAudit,
} from "../../lib/attendance";

const router: IRouter = Router();

router.use(requireLecturer);

router.get(
  "/classes/:classId/sessions",
  async (req, res): Promise<void> => {
    const params = ListClassSessionsParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const classroom = await findOwnedClass(params.data.classId, req.userId!);
    if (!classroom) {
      res.status(404).json({ error: "Class not found." });
      return;
    }
    res.json(
      ListClassSessionsResponse.parse(await getClassSessions(classroom.id)),
    );
  },
);

router.post(
  "/classes/:classId/sessions",
  async (req, res): Promise<void> => {
    const params = CreateSessionParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = CreateSessionBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const classroom = await findOwnedClass(params.data.classId, req.userId!);
    if (!classroom) {
      res.status(404).json({ error: "Class not found." });
      return;
    }

    if (parsed.data.endsAt <= parsed.data.startsAt) {
      res.status(400).json({ error: "Session end time must be after start time." });
      return;
    }

    const [session] = await db
      .insert(attendanceSessionsTable)
      .values({
        classId: classroom.id,
        topic: parsed.data.topic.trim(),
        startsAt: parsed.data.startsAt,
        endsAt: parsed.data.endsAt,
        venue: parsed.data.venue.trim(),
        expectedStudents: parsed.data.expectedStudents,
        codeMode: parsed.data.codeMode,
        radiusM: parsed.data.radiusM ?? 100,
        status: parsed.data.openImmediately ? "open" : "scheduled",
      })
      .returning();

    await writeAttendanceAudit(
      req.userId!,
      "session",
      session.id,
      "session_created",
      { courseCode: classroom.courseCode, status: session.status },
    );
    res.status(201).json(
      CreateSessionResponse.parse(await getSessionItem(session)),
    );
  },
);

router.get("/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = GetSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const session = await findOwnedSession(params.data.sessionId, req.userId!);
  if (!session) {
    res.status(404).json({ error: "Session not found." });
    return;
  }
  res.json(GetSessionResponse.parse(await getSessionDetail(session)));
});

router.get(
  "/sessions/:sessionId/code",
  async (req, res): Promise<void> => {
    const params = GetSessionCodeParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const session = await findOwnedSession(params.data.sessionId, req.userId!);
    if (!session) {
      res.status(404).json({ error: "Session not found." });
      return;
    }
    if (session.status !== "open") {
      res.status(409).json({ error: "The session is not open." });
      return;
    }

    const secret = process.env.SESSION_SECRET;
    if (!secret) {
      res.status(503).json({ error: "Session code signing is not configured." });
      return;
    }

    const currentInterval = Math.floor(Date.now() / 45_000);
    const interval = session.codeMode === "static" ? 0 : currentInterval;
    const signature = createHmac("sha256", secret)
      .update(`${session.id}|${session.codeMode === "static" ? "static" : interval}`)
      .digest();
    const code = encodeBase32(signature).slice(0, 6);
    const qrPayload = Buffer.from(
      `${session.id}|${interval}|${signature.toString("hex").slice(0, 32)}`,
    ).toString("base64url");
    const rotatesInSeconds =
      session.codeMode === "static"
        ? 0
        : Math.ceil(((currentInterval + 1) * 45_000 - Date.now()) / 1_000);

    res.json(
      GetSessionCodeResponse.parse({
        sessionId: session.id,
        code: `${code.slice(0, 3)}-${code.slice(3)}`,
        qrPayload,
        mode: session.codeMode,
        rotatesInSeconds,
        securityNotice:
          session.codeMode === "static"
            ? "Static display code only; record attendance manually in this pilot build."
            : "Rotating display code only; student check-in, face, liveness, and device checks are not active.",
      }),
    );
  },
);

router.post(
  "/sessions/:sessionId/close",
  async (req, res): Promise<void> => {
    const params = CloseSessionParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const session = await findOwnedSession(params.data.sessionId, req.userId!);
    if (!session) {
      res.status(404).json({ error: "Session not found." });
      return;
    }
    if (session.status !== "open") {
      res.status(409).json({ error: "Only an open session can be closed." });
      return;
    }
    const [closed] = await db
      .update(attendanceSessionsTable)
      .set({ status: "closed" })
      .where(eq(attendanceSessionsTable.id, session.id))
      .returning();
    await writeAttendanceAudit(
      req.userId!,
      "session",
      session.id,
      "session_closed",
    );
    res.json(CloseSessionResponse.parse(await getSessionItem(closed)));
  },
);

router.post(
  "/sessions/:sessionId/finalize",
  async (req, res): Promise<void> => {
    const params = FinalizeSessionParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const session = await findOwnedSession(params.data.sessionId, req.userId!);
    if (!session) {
      res.status(404).json({ error: "Session not found." });
      return;
    }
    if (session.status === "finalized") {
      res.status(409).json({ error: "This session is already finalized." });
      return;
    }
    if (session.status !== "closed") {
      res.status(409).json({ error: "Close the session before finalizing it." });
      return;
    }

    await db.transaction(async (tx) => {
      const roster = await tx
        .select({ id: attendanceRosterTable.id })
        .from(attendanceRosterTable)
        .where(eq(attendanceRosterTable.classId, session.classId));
      const existing = await tx
        .select({ rosterStudentId: attendanceRecordsTable.rosterStudentId })
        .from(attendanceRecordsTable)
        .where(eq(attendanceRecordsTable.sessionId, session.id));
      const existingIds = new Set(existing.map((record) => record.rosterStudentId));
      const missing = roster.filter((student) => !existingIds.has(student.id));

      if (missing.length > 0) {
        await tx.insert(attendanceRecordsTable).values(
          missing.map((student) => ({
            sessionId: session.id,
            rosterStudentId: student.id,
            status: "absent",
            markedAt: null,
            flags: [],
            note: null,
            markedManually: false,
          })),
        );
      }

      await tx
        .update(attendanceSessionsTable)
        .set({ status: "finalized", finalizedAt: new Date() })
        .where(eq(attendanceSessionsTable.id, session.id));

      await tx.insert(attendanceAuditTable).values({
        actorUserId: req.userId!,
        entityType: "session",
        entityId: session.id,
        action: "session_finalized",
        details: { absencesAdded: missing.length },
      });
    });

    const finalized = await findOwnedSession(session.id, req.userId!);
    if (!finalized) {
      res.status(404).json({ error: "Session not found." });
      return;
    }
    res.json(
      FinalizeSessionResponse.parse(await getSessionDetail(finalized)),
    );
  },
);

router.get(
  "/sessions/:sessionId/review-queue",
  async (req, res): Promise<void> => {
    const params = GetReviewQueueParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const session = await findOwnedSession(params.data.sessionId, req.userId!);
    if (!session) {
      res.status(404).json({ error: "Session not found." });
      return;
    }
    const records = await getSessionRecords(session.id);
    res.json(
      GetReviewQueueResponse.parse(
        records.filter((record) => record.status === "needs_review"),
      ),
    );
  },
);

router.post(
  "/sessions/:sessionId/manual-mark",
  async (req, res): Promise<void> => {
    const params = CreateManualMarkParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = CreateManualMarkBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const session = await findOwnedSession(params.data.sessionId, req.userId!);
    if (!session) {
      res.status(404).json({ error: "Session not found." });
      return;
    }
    if (session.status !== "open") {
      res.status(409).json({
        error: "Manual marks can only be added while the session is open.",
      });
      return;
    }

    const [student] = await db
      .select()
      .from(attendanceRosterTable)
      .where(
        and(
          eq(attendanceRosterTable.classId, session.classId),
          eq(
            attendanceRosterTable.indexNumber,
            parsed.data.indexNumber.trim().toUpperCase(),
          ),
        ),
      )
      .limit(1);
    if (!student) {
      res.status(404).json({ error: "That index number is not on this roster." });
      return;
    }

    let record;
    try {
      [record] = await db
        .insert(attendanceRecordsTable)
        .values({
          sessionId: session.id,
          rosterStudentId: student.id,
          status: parsed.data.status,
          markedAt: new Date(),
          flags: ["MANUAL_MARK"],
          note: parsed.data.reason.trim(),
          markedManually: true,
        })
        .returning();
    } catch (error) {
      if ((error as { code?: string }).code === "23505") {
        res.status(409).json({
          error: "This student already has a mark for the session.",
        });
        return;
      }
      throw error;
    }

    await writeAttendanceAudit(
      req.userId!,
      "attendance_record",
      record.id,
      "manual_mark",
      {
        sessionId: session.id,
        indexNumber: student.indexNumber,
        status: record.status,
        reason: parsed.data.reason.trim(),
      },
    );
    res.status(201).json(
      CreateManualMarkResponse.parse({
        id: record.id,
        sessionId: record.sessionId,
        studentName: student.fullName,
        indexNumber: student.indexNumber,
        status: record.status,
        markedAt: record.markedAt,
        flags: record.flags,
        note: record.note,
        markedManually: record.markedManually,
      }),
    );
  },
);

router.post(
  "/records/:recordId/decision",
  async (req, res): Promise<void> => {
    const params = DecideAttendanceRecordParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = DecideAttendanceRecordBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const [result] = await db
      .select({
        record: attendanceRecordsTable,
        studentName: attendanceRosterTable.fullName,
        indexNumber: attendanceRosterTable.indexNumber,
        sessionOwnerId: attendanceClassesTable.ownerUserId,
        sessionStatus: attendanceSessionsTable.status,
      })
      .from(attendanceRecordsTable)
      .innerJoin(
        attendanceRosterTable,
        eq(attendanceRecordsTable.rosterStudentId, attendanceRosterTable.id),
      )
      .innerJoin(
        attendanceSessionsTable,
        eq(attendanceRecordsTable.sessionId, attendanceSessionsTable.id),
      )
      .innerJoin(
        attendanceClassesTable,
        eq(attendanceSessionsTable.classId, attendanceClassesTable.id),
      )
      .where(
        and(
          eq(attendanceRecordsTable.id, params.data.recordId),
          eq(attendanceClassesTable.ownerUserId, req.userId!),
        ),
      )
      .limit(1);
    if (!result) {
      res.status(404).json({ error: "Attendance record not found." });
      return;
    }
    if (result.sessionStatus === "finalized") {
      res.status(409).json({ error: "Finalized attendance cannot be changed." });
      return;
    }
    if (result.record.status !== "needs_review") {
      res.status(409).json({ error: "Only marks needing review can be decided." });
      return;
    }

    const [updated] = await db
      .update(attendanceRecordsTable)
      .set({
        status: parsed.data.status,
        note: parsed.data.note ?? result.record.note,
        reviewedBy: req.userId!,
        reviewedAt: new Date(),
      })
      .where(eq(attendanceRecordsTable.id, result.record.id))
      .returning();
    await writeAttendanceAudit(
      req.userId!,
      "attendance_record",
      result.record.id,
      "review_decision",
      {
        sessionId: result.record.sessionId,
        indexNumber: result.indexNumber,
        status: updated.status,
        note: updated.note,
      },
    );
    res.json(
      DecideAttendanceRecordResponse.parse({
        id: updated.id,
        sessionId: updated.sessionId,
        studentName: result.studentName,
        indexNumber: result.indexNumber,
        status: updated.status,
        markedAt: updated.markedAt,
        flags: updated.flags,
        note: updated.note,
        markedManually: updated.markedManually,
      }),
    );
  },
);

export default router;

function encodeBase32(bytes: Buffer): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let output = "";
  let buffer = 0;
  let bits = 0;

  for (const byte of bytes) {
    buffer = (buffer << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(buffer >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += alphabet[(buffer << (5 - bits)) & 31];
  }
  return output;
}

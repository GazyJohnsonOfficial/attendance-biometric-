import { and, desc, eq, inArray } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  GetAttendanceActivityResponse,
  GetAttendanceOverviewResponse,
  GetClassReportParams,
  GetClassReportResponse,
} from "@workspace/api-zod";
import {
  attendanceAuditTable,
  attendanceClassesTable,
  attendanceRecordsTable,
  attendanceRosterTable,
  attendanceSessionsTable,
  db,
} from "@workspace/db";
import requireLecturer from "../../middlewares/requireLecturer";
import { findOwnedClass, getClassItem, getSessionItem } from "../../lib/attendance";

const router: IRouter = Router();

router.use(requireLecturer);

router.get("/overview", async (req, res): Promise<void> => {
  const classrooms = await db
    .select()
    .from(attendanceClassesTable)
    .where(
      and(
        eq(attendanceClassesTable.ownerUserId, req.userId!),
        eq(attendanceClassesTable.archived, false),
      ),
    );
  const classIds = classrooms.map((classroom) => classroom.id);
  const classItems = await Promise.all(classrooms.map(getClassItem));
  const rosterCounts = new Map(
    classItems.map((classroom) => [classroom.id, classroom.rosterCount]),
  );
  const rosterCount = classItems.reduce(
    (total, classroom) => total + classroom.rosterCount,
    0,
  );
  const sessions =
    classIds.length > 0
      ? await db
          .select()
          .from(attendanceSessionsTable)
          .where(inArray(attendanceSessionsTable.classId, classIds))
          .orderBy(desc(attendanceSessionsTable.startsAt))
      : [];
  const now = new Date();
  const thisWeekStart = startOfUtcWeek(now);
  const finalizedSessions = sessions.filter(
    (session) => session.status === "finalized",
  );
  const finalizedIds = finalizedSessions.map((session) => session.id);
  const finalRecords =
    finalizedIds.length > 0
      ? await db
          .select({
            sessionId: attendanceRecordsTable.sessionId,
            status: attendanceRecordsTable.status,
          })
          .from(attendanceRecordsTable)
          .where(inArray(attendanceRecordsTable.sessionId, finalizedIds))
      : [];
  const checkedInFinalRecords = finalRecords.filter(
    (record) => record.status === "present" || record.status === "excused",
  );
  const expectedFinal = finalizedSessions.reduce(
    (total, session) =>
      total + (rosterCounts.get(session.classId) ?? 0),
    0,
  );
  const activeSessions = sessions.filter((session) => session.status === "open");
  const reviewSessionIds = sessions.map((session) => session.id);
  const reviewRecords =
    reviewSessionIds.length > 0
      ? await db
          .select({ id: attendanceRecordsTable.id })
          .from(attendanceRecordsTable)
          .where(
            and(
              inArray(attendanceRecordsTable.sessionId, reviewSessionIds),
              eq(attendanceRecordsTable.status, "needs_review"),
            ),
          )
      : [];

  const attendanceByWeek = buildWeekBuckets(
    now,
    finalizedSessions,
    checkedInFinalRecords,
    rosterCounts,
  );
  const overview = {
    classCount: classrooms.length,
    rosterCount,
    sessionsThisWeek: sessions.filter(
      (session) =>
        session.startsAt >= thisWeekStart &&
        session.startsAt <= endOfUtcWeek(now),
    ).length,
    reviewCount: reviewRecords.length,
    attendanceRate:
      expectedFinal > 0
        ? Math.round((checkedInFinalRecords.length / expectedFinal) * 100)
        : 0,
    attendanceByWeek,
    activeSessions: await Promise.all(
      activeSessions.map((session) => getSessionItem(session)),
    ),
  };

  res.json(GetAttendanceOverviewResponse.parse(overview));
});

router.get("/activity", async (req, res): Promise<void> => {
  const events = await db
    .select()
    .from(attendanceAuditTable)
    .where(eq(attendanceAuditTable.actorUserId, req.userId!))
    .orderBy(desc(attendanceAuditTable.createdAt))
    .limit(12);

  res.json(
    GetAttendanceActivityResponse.parse(
      events.map((event) => {
        const details = event.details ?? {};
        const detail = describeActivity(event.action, details);
        return {
          id: event.id,
          action: labelActivity(event.action),
          detail,
          occurredAt: event.createdAt,
          tone: event.action.includes("dispute")
            ? "warning"
            : event.action.includes("created") ||
                event.action.includes("committed") ||
                event.action.includes("finalized")
              ? "success"
              : "neutral",
        };
      }),
    ),
  );
});

router.get(
  "/classes/:classId/reports/summary",
  async (req, res): Promise<void> => {
    const params = GetClassReportParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const classroom = await findOwnedClass(params.data.classId, req.userId!);
    if (!classroom) {
      res.status(404).json({ error: "Class not found." });
      return;
    }

    const [roster, sessions] = await Promise.all([
      db
        .select()
        .from(attendanceRosterTable)
        .where(eq(attendanceRosterTable.classId, classroom.id))
        .orderBy(attendanceRosterTable.fullName),
      db
        .select()
        .from(attendanceSessionsTable)
        .where(
          and(
            eq(attendanceSessionsTable.classId, classroom.id),
            eq(attendanceSessionsTable.status, "finalized"),
          ),
        ),
    ]);
    const sessionIds = sessions.map((session) => session.id);
    const records =
      sessionIds.length > 0
        ? await db
            .select({
              rosterStudentId: attendanceRecordsTable.rosterStudentId,
              status: attendanceRecordsTable.status,
            })
            .from(attendanceRecordsTable)
            .where(inArray(attendanceRecordsTable.sessionId, sessionIds))
        : [];
    const attendanceThreshold = 75;
    const studentSummaries = roster.map((student) => {
      const attended = records.filter(
        (record) =>
          record.rosterStudentId === student.id &&
          (record.status === "present" || record.status === "excused"),
      ).length;
      const percentage =
        sessions.length > 0
          ? Math.round((attended / sessions.length) * 100)
          : 0;
      return {
        fullName: student.fullName,
        indexNumber: student.indexNumber,
        attended,
        total: sessions.length,
        percentage,
      };
    });

    res.json(
      GetClassReportResponse.parse({
        classId: classroom.id,
        attendanceThreshold,
        totalSessions: sessions.length,
        students: studentSummaries,
        belowThreshold:
          sessions.length > 0
            ? studentSummaries.filter(
                (student) => student.percentage < attendanceThreshold,
              )
            : [],
      }),
    );
  },
);

export default router;

function startOfUtcWeek(date: Date): Date {
  const result = new Date(date);
  result.setUTCHours(0, 0, 0, 0);
  result.setUTCDate(result.getUTCDate() - ((result.getUTCDay() + 6) % 7));
  return result;
}

function endOfUtcWeek(date: Date): Date {
  const result = startOfUtcWeek(date);
  result.setUTCDate(result.getUTCDate() + 7);
  result.setUTCMilliseconds(result.getUTCMilliseconds() - 1);
  return result;
}

function buildWeekBuckets(
  now: Date,
  sessions: Array<{
    id: string;
    classId: string;
    startsAt: Date;
  }>,
  attendedRecords: Array<{ sessionId: string }>,
  rosterCounts: Map<string, number>,
) {
  const currentWeek = startOfUtcWeek(now);
  return Array.from({ length: 6 }, (_, index) => {
    const weekStart = new Date(currentWeek);
    weekStart.setUTCDate(weekStart.getUTCDate() - (5 - index) * 7);
    const weekEnd = new Date(weekStart);
    weekEnd.setUTCDate(weekEnd.getUTCDate() + 7);
    const weekSessions = sessions.filter(
      (session) => session.startsAt >= weekStart && session.startsAt < weekEnd,
    );
    const sessionIds = new Set(weekSessions.map((session) => session.id));
    const attended = attendedRecords.filter((record) =>
      sessionIds.has(record.sessionId),
    ).length;
    const expected = weekSessions.reduce(
      (total, session) => total + (rosterCounts.get(session.classId) ?? 0),
      0,
    );
    const label = weekStart.toLocaleDateString("en-GB", {
      month: "short",
      day: "numeric",
      timeZone: "UTC",
    });

    return {
      week: label,
      attended,
      expected,
    };
  });
}

function labelActivity(action: string): string {
  const labels: Record<string, string> = {
    class_created: "Class created",
    class_updated: "Class details updated",
    roster_committed: "Roster saved",
    session_created: "Attendance session created",
    session_closed: "Session closed",
    session_finalized: "Attendance finalized",
    manual_mark: "Manual mark recorded",
    review_decision: "Review decision saved",
  };
  return labels[action] ?? "Attendance activity";
}

function describeActivity(
  action: string,
  details: Record<string, unknown>,
): string {
  const course = typeof details.courseCode === "string" ? details.courseCode : "";
  const rowCount =
    typeof details.rowCount === "number" ? details.rowCount : undefined;
  const absencesAdded =
    typeof details.absencesAdded === "number" ? details.absencesAdded : undefined;

  if (action === "roster_committed" && rowCount !== undefined) {
    return `${rowCount} roster rows saved`;
  }
  if (action === "session_finalized" && absencesAdded !== undefined) {
    return `${absencesAdded} unmarked students set absent`;
  }
  if (course) {
    return course;
  }
  if (action === "manual_mark" && typeof details.indexNumber === "string") {
    return `Index ${details.indexNumber}`;
  }
  return "Your attendance workspace was updated";
}

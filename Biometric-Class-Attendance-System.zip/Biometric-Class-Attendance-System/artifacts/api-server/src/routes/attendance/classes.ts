import { and, desc, eq, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CommitRosterBody,
  CommitRosterParams,
  CommitRosterResponse,
  CreateClassBody,
  CreateClassResponse,
  GetClassParams,
  GetClassResponse,
  GetClassRosterParams,
  GetClassRosterResponse,
  ListClassesResponse,
  PreviewRosterBody,
  PreviewRosterParams,
  PreviewRosterResponse,
  UpdateClassBody,
  UpdateClassParams,
  UpdateClassResponse,
} from "@workspace/api-zod";
import {
  attendanceClassesTable,
  attendanceRosterTable,
  db,
} from "@workspace/db";
import requireLecturer from "../../middlewares/requireLecturer";
import {
  findOwnedClass,
  getClassItem,
  getClassSessions,
  getRosterResponse,
  writeAttendanceAudit,
} from "../../lib/attendance";

const router: IRouter = Router();

router.use(requireLecturer);

router.get("/classes", async (req, res): Promise<void> => {
  const classrooms = await db
    .select()
    .from(attendanceClassesTable)
    .where(
      and(
        eq(attendanceClassesTable.ownerUserId, req.userId!),
        eq(attendanceClassesTable.archived, false),
      ),
    )
    .orderBy(desc(attendanceClassesTable.createdAt));

  const data = await Promise.all(classrooms.map((row) => getClassItem(row)));
  res.json(ListClassesResponse.parse(data));
});

router.post("/classes", async (req, res): Promise<void> => {
  const parsed = CreateClassBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let classroom;
  try {
    [classroom] = await db
      .insert(attendanceClassesTable)
      .values({
        ...parsed.data,
        ownerUserId: req.userId!,
      })
      .returning();
  } catch (error) {
    if ((error as { code?: string }).code === "23505") {
      res.status(409).json({
        error: "A class with this course, semester, and year already exists.",
      });
      return;
    }
    throw error;
  }

  await writeAttendanceAudit(
    req.userId!,
    "class",
    classroom.id,
    "class_created",
    { courseCode: classroom.courseCode, courseTitle: classroom.courseTitle },
  );

  res.status(201).json(
    CreateClassResponse.parse(await getClassItem(classroom)),
  );
});

router.get("/classes/:classId", async (req, res): Promise<void> => {
  const params = GetClassParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const classroom = await findOwnedClass(params.data.classId, req.userId!);
  if (!classroom) {
    res.status(404).json({ error: "Class not found." });
    return;
  }

  const [classItem, recentSessions] = await Promise.all([
    getClassItem(classroom),
    getClassSessions(classroom.id),
  ]);
  res.json(GetClassResponse.parse({ classroom: classItem, recentSessions }));
});

router.patch("/classes/:classId", async (req, res): Promise<void> => {
  const params = UpdateClassParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateClassBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const classroom = await findOwnedClass(params.data.classId, req.userId!);
  if (!classroom) {
    res.status(404).json({ error: "Class not found." });
    return;
  }
  if (Object.keys(parsed.data).length === 0) {
    res.status(400).json({ error: "Provide at least one class field to update." });
    return;
  }

  let updated;
  try {
    [updated] = await db
      .update(attendanceClassesTable)
      .set(parsed.data)
      .where(eq(attendanceClassesTable.id, classroom.id))
      .returning();
  } catch (error) {
    if ((error as { code?: string }).code === "23505") {
      res.status(409).json({
        error: "A class with this course, semester, and year already exists.",
      });
      return;
    }
    throw error;
  }

  await writeAttendanceAudit(
    req.userId!,
    "class",
    classroom.id,
    "class_updated",
    { fields: Object.keys(parsed.data) },
  );
  res.json(UpdateClassResponse.parse(await getClassItem(updated)));
});

router.get(
  "/classes/:classId/roster",
  async (req, res): Promise<void> => {
    const params = GetClassRosterParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const classroom = await findOwnedClass(params.data.classId, req.userId!);
    if (!classroom) {
      res.status(404).json({ error: "Class not found." });
      return;
    }
    res.json(
      GetClassRosterResponse.parse(await getRosterResponse(classroom.id)),
    );
  },
);

router.post(
  "/classes/:classId/roster/preview",
  async (req, res): Promise<void> => {
    const params = PreviewRosterParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = PreviewRosterBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const classroom = await findOwnedClass(params.data.classId, req.userId!);
    if (!classroom) {
      res.status(404).json({ error: "Class not found." });
      return;
    }

    res.json(
      PreviewRosterResponse.parse(buildRosterPreview(parsed.data.rows)),
    );
  },
);

router.post(
  "/classes/:classId/roster/commit",
  async (req, res): Promise<void> => {
    const params = CommitRosterParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = CommitRosterBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const classroom = await findOwnedClass(params.data.classId, req.userId!);
    if (!classroom) {
      res.status(404).json({ error: "Class not found." });
      return;
    }

    const preview = buildRosterPreview(parsed.data.rows);
    const invalidRows = preview.rows.filter(
      (row) => row.status === "error" || row.status === "conflict",
    );
    if (invalidRows.length > 0) {
      res.status(400).json({
        error: "Fix roster errors and duplicate index numbers before saving.",
        rows: invalidRows,
      });
      return;
    }

    const rows = parsed.data.rows.map((row) => ({
      classId: classroom.id,
      fullName: row.fullName.trim(),
      indexNumber: row.indexNumber.trim().toUpperCase(),
      email: row.email.trim().toLowerCase(),
      phone: row.phone?.trim() || null,
      linkStatus: "invited",
      faceEnrolled: false,
    }));

    if (rows.length > 0) {
      await db
        .insert(attendanceRosterTable)
        .values(rows)
        .onConflictDoUpdate({
          target: [
            attendanceRosterTable.classId,
            attendanceRosterTable.indexNumber,
          ],
          set: {
            fullName: sql`excluded.full_name`,
            email: sql`excluded.email`,
            phone: sql`excluded.phone`,
            linkStatus: sql`case
              when ${attendanceRosterTable.email} <> excluded.email then 'invited'
              else ${attendanceRosterTable.linkStatus}
            end`,
          },
        });
    }

    await writeAttendanceAudit(
      req.userId!,
      "class",
      classroom.id,
      "roster_committed",
      { rowCount: rows.length },
    );
    res.json(
      CommitRosterResponse.parse(await getRosterResponse(classroom.id)),
    );
  },
);

export default router;

function buildRosterPreview(
  inputRows: Array<{
    fullName: string;
    indexNumber: string;
    email: string;
    phone?: string | null;
  }>,
) {
  const normalized = inputRows.map((row) => ({
    fullName: row.fullName.trim(),
    indexNumber: row.indexNumber.trim().toUpperCase(),
    email: row.email.trim().toLowerCase(),
    phone: row.phone?.trim() || null,
  }));
  const indexes = new Map<string, number[]>();

  normalized.forEach((row, index) => {
    indexes.set(row.indexNumber, [...(indexes.get(row.indexNumber) ?? []), index]);
  });

  const rows = normalized.map((row) => {
    const issues: string[] = [];
    if (row.fullName.length < 2 || row.fullName.length > 100) {
      issues.push("Student name must be between 2 and 100 characters.");
    }
    if (row.indexNumber.length > 32 || !/^[A-Z0-9]+$/.test(row.indexNumber)) {
      issues.push("Index number must use up to 32 letters and numbers.");
    }
    if (
      row.email.length > 254 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)
    ) {
      issues.push("Enter a valid email address.");
    }

    const duplicateIndexes = indexes.get(row.indexNumber) ?? [];
    let status: "ready" | "error" | "conflict" = "ready";
    if (issues.length > 0) {
      status = "error";
    } else if (duplicateIndexes.length > 1) {
      const duplicateEmails = new Set(
        duplicateIndexes.map((index) => normalized[index]?.email),
      );
      if (duplicateEmails.size > 1) {
        status = "conflict";
        issues.push("This index number appears with different email addresses.");
      } else {
        status = "error";
        issues.push("This index number appears more than once.");
      }
    }

    return { ...row, status, issues };
  });

  return {
    totalRows: rows.length,
    validRows: rows.filter((row) => row.status === "ready").length,
    errorRows: rows.filter((row) => row.status === "error").length,
    conflictRows: rows.filter((row) => row.status === "conflict").length,
    rows,
  };
}
